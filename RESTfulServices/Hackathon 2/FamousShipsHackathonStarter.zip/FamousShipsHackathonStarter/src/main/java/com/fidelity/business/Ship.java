package com.fidelity.business;

public class Ship {
	private long id;
	private String name;
	private String nickname;
	private String captain;
	private String description;
	private String type;
	
	
	
}

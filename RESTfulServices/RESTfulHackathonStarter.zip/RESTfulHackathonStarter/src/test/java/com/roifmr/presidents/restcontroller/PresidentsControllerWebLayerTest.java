package com.roifmr.presidents.restcontroller;

import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;

@WebMvcTest
public class PresidentsControllerWebLayerTest {

}

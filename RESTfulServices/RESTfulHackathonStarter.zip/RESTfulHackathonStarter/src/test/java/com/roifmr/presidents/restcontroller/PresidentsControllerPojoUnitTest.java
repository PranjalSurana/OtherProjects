package com.roifmr.presidents.restcontroller;

public class PresidentsControllerPojoUnitTest {

}

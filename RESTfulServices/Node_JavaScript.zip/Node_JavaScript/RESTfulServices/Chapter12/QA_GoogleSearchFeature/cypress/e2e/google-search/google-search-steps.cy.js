/// <reference types="Cypress" />

// Running Cucumber with Cypress 10 requires a custom preprocessor
import { Given, When, Then } from '@badeball/cypress-cucumber-preprocessor';

// TODO: define the URL for Google


//-------------------------
// Scenario 1
// ------------------------

// TODO: Define the Given, When, and Then steps for Scenario 1



//-------------------------
// Scenario 2
// ------------------------

// TODO: Define the When and Then steps for Scenario 2
//       Note: don't duplicate the Given step from Scenario 1



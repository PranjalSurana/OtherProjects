/*
 * This is a simple calculator class for testing Cucumber
 */
class Calculator { 
    constructor() {}
    
    add(a, b) {
        return a + b;
    }
}

module.exports = Calculator;

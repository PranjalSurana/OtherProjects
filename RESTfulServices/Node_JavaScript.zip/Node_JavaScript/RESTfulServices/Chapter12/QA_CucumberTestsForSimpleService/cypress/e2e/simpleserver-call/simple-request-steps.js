import { expect } from "chai";
import { Given, When, Then } from '@badeball/cypress-cucumber-preprocessor';

//-------------------------
// Scenario 1
// ------------------------

const url = 'http://localhost:3000';

// TODO Define a variable for the HTTP response body
// HINT See slide 12-41


// TODO Define the Given, When, and Then steps for Scenario 1
// HINT See slide 12-41 and 12-42



// TODO Run Cypress with `npm test` and verify that the test case for Scenario 1 passes



// BONUS TODO: After the test case for the first scenario passes, 
//             define the When and Then steps for Scenario 2
//             Note: don't duplicate the Given step from Scenario 1

//-------------------------
// Scenario 2
// ------------------------



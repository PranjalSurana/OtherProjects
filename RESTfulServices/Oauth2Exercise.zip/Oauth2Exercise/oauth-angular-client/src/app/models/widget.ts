export class Widget {
  constructor(
    public id: number,
    public description: string,
    public price: number,
    public gears: number,
    public sprockets: number) { }
}

package com.bowling.scoring;

import com.bowling.model.BowlingGame;

public interface BowlingScorer {
	int calculateScore(BowlingGame game);
}

package com.bowling.model;

public class BowlingGame {
	private final int FRAMES_COUNT = 10;
	private Frame[] frames;
	private Frame extraFrame;
	
	public BowlingGame() {
		frames = new Frame[FRAMES_COUNT];
		extraFrame = new Frame();
		
		// The 10th Frame has a reference to the extraFrame
		frames[FRAMES_COUNT - 1] = new Frame(0, 0, extraFrame);
		
		// Every Frame has a reference to the next Frame
		for(int i = FRAMES_COUNT - 2; i >= 0; i--) {
			Frame frame = new Frame(0, 0, frames[i + 1]);
			frames[i] = frame;			
		}		
	}
	
	public BowlingGame(Frame[] frames) {
		this.frames = frames;
	}
	
	public Frame[] getFrames() {
		return frames;
	}
}

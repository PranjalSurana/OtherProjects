package com.bowling.model;

public class Frame {
	private int firstRoll;
	private int secondRoll;
	private Frame nextFrame;
	
	public Frame() {}
	
	public Frame(int firstRoll, int secondRoll) {
		this(firstRoll, secondRoll, null);
	}
	
	public Frame(int firstRoll, int secondRoll, Frame nextFrame) {
		this.firstRoll = firstRoll;
		this.secondRoll = secondRoll;
		this.nextFrame = nextFrame;
	}
	
	public int getScore() {
		int score = firstRoll + secondRoll;
		
		// Strike! Add the total of the next two rolls
		if (firstRoll == 10) {
			if (nextFrame != null) {
				score += nextFrame.firstRoll + nextFrame.secondRoll;
				if (nextFrame.nextFrame != null && nextFrame.firstRoll == 10) {				
						score += nextFrame.nextFrame.firstRoll;
				}
			}
		}
		// Spare! Add the next roll
		else if(score == 10) {
			if (nextFrame != null) {
				score += nextFrame.firstRoll;
			}
		}
					
		return score;
	}
	
}

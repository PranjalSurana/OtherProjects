package com.bowling.model;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class FrameTest {
	Frame frame;
	
	@BeforeEach
	void setUp() throws Exception {
		frame = new Frame();
	}

	@Test
	void testFrameNoArgConstructor() {
		assertNotNull(frame);
	}

	@Test
	void testFrameIntIntConstructor() {
		int roll1 = 5;
		int roll2 = 5;
		frame = new Frame(roll1, roll2);
		
		assertNotNull(frame);
	}

	@Test
	void testFrameIntIntFrameConstructor() {
		int roll1 = 5;
		int roll2 = 5;
		Frame nextFrame = new Frame();
		frame = new Frame(roll1, roll2, nextFrame);
		
		assertNotNull(frame);
	}

	@Test
	void testGetScoreSad() {
		int roll1 = 5;
		int roll2 = 4;
		Frame nextFrame = new Frame();
		frame = new Frame(roll1, roll2, nextFrame);
		int expected = roll1 + roll2;
		int actual = frame.getScore();
		
		assertEquals(expected, actual);
	}

	@Test
	void testGetScoreSpare() {
		int roll1 = 5;
		int roll2 = 5;
		int nextRoll1 = 6;
		int nextRoll2 = 0;
		Frame nextFrame = new Frame(nextRoll1, nextRoll2);
		frame = new Frame(roll1, roll2, nextFrame);
		int expected = roll1 + roll2 + nextRoll1;
		int actual = frame.getScore();
		
		assertEquals(expected, actual);
	}
	
	@Test
	void testGetScoreStrike() {
		int roll1 = 10;
		int roll2 = 0;
		int nextRoll1 = 6;
		int nextRoll2 = 3;
		Frame nextFrame = new Frame(nextRoll1, nextRoll2);
		frame = new Frame(roll1, roll2, nextFrame);
		int expected = roll1 + roll2 + nextRoll1 + nextRoll2;
		int actual = frame.getScore();
		
		assertEquals(expected, actual);
	}
	
	@Test
	void testGetScoreStrikeStrikeStrike() {
		int roll1 = 10;
		int roll2 = 0;
		int nextRoll1 = 10;
		int nextRoll2 = 0;
		int thirdRoll1 = 10;
		int thirdRoll2 = 0; 
		Frame thirdFrame = new Frame(thirdRoll1, thirdRoll2);
		Frame secondFrame = new Frame(nextRoll1, nextRoll2, thirdFrame);
		frame = new Frame(roll1, roll2, secondFrame);
		int expected = roll1 + roll2 + nextRoll1 + nextRoll2 + thirdRoll1 + thirdRoll2;
		int actual = frame.getScore();
		
		assertEquals(expected, actual);
	}		
}

package com.fidelity.accounts;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Collection;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.fidelity.model.Account;
import com.fidelity.model.DebitAccount;
import com.fidelity.model.GicAccount;
import com.fidelity.model.SavingsAccount;

/**
 * AccountPortalTest defines unit tests for AccountPortal.
 * 
 * @author ROI Instructor Team
 */
public class AccountPortalTest {
	private Account debitAccount;
	private Account savingAccount;
	private Account gicAccount;
	private AccountPortal portalCapacity3;

	@BeforeEach
	void setUp() throws Exception {
		debitAccount = new DebitAccount("debitAccount01", new BigDecimal("200.00"), new BigDecimal("10.00"));
		savingAccount = new SavingsAccount("savingAccount02", new BigDecimal("400.00"), LocalDate.of(2019, 6, 5));
		gicAccount = new GicAccount("gicAccount03", new BigDecimal("1000.00"), LocalDate.of(2019, 6, 5), new BigDecimal("20.00"), 6 );
		
		portalCapacity3 = new AccountPortal(UUID.randomUUID().toString(), 3);
	}

	@Test
	void getMaximumNumberOfAccounts_InitialValue() {
		int max = portalCapacity3.getMaximumNumberOfAccounts();
		
		assertEquals(3, max);
	}

	@Test
	void getRemainingSpaceForAccounts_InitialValue() {
		int remaining = portalCapacity3.getRemainingSpaceForAccounts();
		
		assertEquals(3, remaining);
	}

	@Test
	@SuppressWarnings("deprecation")
	void getAllAccounts() {
		Set<Account> expectedAccounts = 
				new HashSet<>(Set.of(debitAccount, savingAccount, gicAccount));

		portalCapacity3.setPortfolio(expectedAccounts);
		
		Collection<Account> portfolio = portalCapacity3.getPortfolio();
		
		assertEquals(expectedAccounts, portfolio);
	}

	@Test
	void addAccount_OneAccount() {
		// This test case calls AccountPortal methods to verify other
		// AccountPortal methods. This generally is not a good practice, 
		// but for now it's the best we can do. We'll learn better ways 
		// to test in the Spring/MyBatis course.

		// verify there are no Accounts present yet
		assertEquals(0, portalCapacity3.getPortfolio().size());
		
		portalCapacity3.addAccount(debitAccount);

		assertEquals(1, portalCapacity3.getPortfolio().size());
		assertTrue(portalCapacity3.getPortfolio().contains(debitAccount));
	}

	@Test
	void addAccount_TwoAccounts() {
		// verify there are no Accounts present yet
		assertEquals(0, portalCapacity3.getPortfolio().size());
		
		portalCapacity3.addAccount(debitAccount);
		portalCapacity3.addAccount(savingAccount);

		// verify both new Accounts were added
		assertEquals(2, portalCapacity3.getPortfolio().size());
		assertTrue(portalCapacity3.getPortfolio().contains(debitAccount));
		assertTrue(portalCapacity3.getPortfolio().contains(savingAccount));
	}

	@Test
	void addAccount_DuplicateAccount_ThrowsException() {
		portalCapacity3.addAccount(debitAccount);
		Collection<Account> expectedPortfolio = portalCapacity3.getPortfolio();

		Account acctWithDupeId = new DebitAccount(debitAccount.getAccountNumber(), 
												  new BigDecimal("300.00"), new BigDecimal("30.00"));
		assertThrows(AccountPortalException.class, () -> {
			portalCapacity3.addAccount(acctWithDupeId);
		});
		// verify portfolio didn't change
		assertEquals(expectedPortfolio, portalCapacity3.getPortfolio());
	}

	@Test
	void getRemainingSpaceForAccounts_OneAccount() {
		portalCapacity3.addAccount(debitAccount);

		int remaining = portalCapacity3.getRemainingSpaceForAccounts();
		
		assertEquals(2, remaining);
	}

	@Test
	void getRemainingSpaceForAccounts_MaxAccounts() {
		// This test calls the portal's addAccount() method to set up the call to
		// getRemainingSpaceForAccounts(), which is method under test. Generally,
		// it's not a good practice to call methods of the class being tested
		// in the "arrange" or "assert" steps. However, we haven't seen an easy
		// way to avoid this yet, so we'll live it for now. In the Spring class,
		// we'll see better ways to handle this situation.
		portalCapacity3.addAccount(debitAccount);
		portalCapacity3.addAccount(savingAccount);
		portalCapacity3.addAccount(gicAccount);

		int remaining = portalCapacity3.getRemainingSpaceForAccounts();
		
		assertEquals(0, remaining);
	}

	@Test
	void addAccount_PortalAtCapacity_ThrowsException() {
		portalCapacity3.addAccount(debitAccount);
		portalCapacity3.addAccount(savingAccount);
		portalCapacity3.addAccount(gicAccount);
		Collection<Account> expectedPortfolio = portalCapacity3.getPortfolio();

		assertThrows(IllegalStateException.class, () -> {
			portalCapacity3.addAccount(debitAccount);
		});
		// verify portfolio didn't change
		assertEquals(expectedPortfolio, portalCapacity3.getPortfolio());
	}
	
	@Test
	void portalConstruction_InitialCapacityZero_ThrowsException() {
		assertThrows(IllegalArgumentException.class, () -> {
			new AccountPortal("client", 0);
		});
	}
	
	@Test
	void portalConstruction_InvalidCapacity_ThrowsException() {
		assertThrows(IllegalArgumentException.class, () -> {
			new AccountPortal(UUID.randomUUID().toString(), 0);
		});
	}
	
	@Test
	void portalConstruction_NonUniqueClientId_ThrowsException() {
		new AccountPortal("client", 10);

		assertThrows(IllegalArgumentException.class, () -> {
			new AccountPortal("client", 10);
		});
	}

	@Test
	void addAccount_NullAccount_ThrowsException() {
		Collection<Account> expectedPortfolio = portalCapacity3.getPortfolio();

		assertThrows(IllegalArgumentException.class, () -> {
			portalCapacity3.addAccount(null);
		});
		// verify portfolio didn't change
		assertEquals(expectedPortfolio, portalCapacity3.getPortfolio());
	}
	
	@Test
	void removeAccount_AccountIsPresent_Success() {
		portalCapacity3.addAccount(debitAccount);
		portalCapacity3.addAccount(gicAccount);
		assertEquals(1, portalCapacity3.getRemainingSpaceForAccounts());
		
		portalCapacity3.removeAccount(gicAccount.getAccountNumber());
		
		assertEquals(2, portalCapacity3.getRemainingSpaceForAccounts());
		assertNull(portalCapacity3.getAccount(gicAccount.getAccountNumber()));
	}
	
	@Test
	void removeAccount_AccountIsNotPresent_ThrowsException() {
		portalCapacity3.addAccount(debitAccount);
		Collection<Account> expectedPortfolio = portalCapacity3.getPortfolio();
		
		assertThrows(IllegalArgumentException.class, () -> {
			portalCapacity3.removeAccount(gicAccount.getAccountNumber());			
		});
		// verify portfolio didn't change
		assertEquals(expectedPortfolio, portalCapacity3.getPortfolio());
	}

	@Test
	void removeAccount_NullArg_ThrowsException() {
		Collection<Account> expectedPortfolio = portalCapacity3.getPortfolio();

		assertThrows(IllegalArgumentException.class, () -> {
			portalCapacity3.removeAccount(null);			
		});
		assertEquals(expectedPortfolio, portalCapacity3.getPortfolio());
	}
	
	@Test
	void getAccountsTotalBalance_NoAccounts() {
		BigDecimal totalBalance = portalCapacity3.getAccountsTotalBalance();
		
		assertEquals(AccountPortal.ZERO_BALANCE, totalBalance);
	}
	
	@Test
	void getAccountsTotalBalance_NoInterestOrFees() {
		LocalDate startDate = LocalDate.now();
		Account debit = new DebitAccount("debitAccount01", new BigDecimal("200.00"), new BigDecimal("10.00"));
		Account saving = new SavingsAccount("account02", new BigDecimal("400.00"), startDate);
		Account gic = new GicAccount("account03", new BigDecimal("1000.00"), startDate, new BigDecimal("20.00"), 6 );
		portalCapacity3.addAccount(debit);
		portalCapacity3.addAccount(saving);
		portalCapacity3.addAccount(gic);
		
		BigDecimal totalBalance = portalCapacity3.getAccountsTotalBalance();
		
		assertEquals(new BigDecimal("1570.00"), totalBalance);
	}
	
	@Test
	void getAccountsTotalBalance_InterestAndFees() {
		LocalDate startDate = LocalDate.now().minusMonths(30);
		Account debit = new DebitAccount("debitAccount01", new BigDecimal("200.00"), new BigDecimal("10.00"));
		Account saving = new SavingsAccount("account02", new BigDecimal("400.00"), startDate);
		Account gic = new GicAccount("account03", new BigDecimal("1000.00"), startDate, new BigDecimal("20.00"), 6 );
		portalCapacity3.addAccount(debit);
		portalCapacity3.addAccount(saving);
		portalCapacity3.addAccount(gic);
		
		BigDecimal totalBalance = portalCapacity3.getAccountsTotalBalance();
		
		assertEquals(new BigDecimal("1632.00"), totalBalance);
	}

	@Test
	void getAccount_AccountIsPresent_Success() {
		portalCapacity3.addAccount(debitAccount);
		portalCapacity3.addAccount(savingAccount);
		portalCapacity3.addAccount(gicAccount);

		Account result = portalCapacity3.getAccount("savingAccount02");
		
		assertEquals(savingAccount, result);
	}

	@Test
	void getAccount_AccountIsNotPresent_NullResult() {
		Account result = portalCapacity3.getAccount("notPresent");
		
		assertNull(result);
	}

	@Test
	void getAccount_NullArg_ThrowsException() {
		assertThrows(IllegalArgumentException.class, () -> {
			portalCapacity3.getAccount(null);			
		});
	}

	@Test
	void getAccount_EmptyArg_ThrowsException() {
		assertThrows(IllegalArgumentException.class, () -> {
			portalCapacity3.getAccount("");			
		});
	}
}

package com.fidelity.model;

import static org.junit.jupiter.api.Assertions.*;

import java.math.BigDecimal;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * DebitAccountTest defines unit tests for DebitAccount.
 * 
 * @author ROI Instructor Team
 */
class DebitAccountTest {
	private static final BigDecimal ONE_HUNDRED = new BigDecimal(100);

	private DebitAccount account;
	
	@BeforeEach
	void setUp() throws Exception {
	}

	@Test
	void createDebitAccount_Success( ) {
		String accountNumber = "debit123";
		account = new DebitAccount(accountNumber, ONE_HUNDRED, BigDecimal.TEN);
		
		String result = account.getAccountNumber();
		
		assertEquals(accountNumber, result);
	}

	@Test
	void createDebitAccount_NullFee_ThrowsException( ) {
		assertThrows(IllegalArgumentException.class, () -> {
			new DebitAccount("debit123", ONE_HUNDRED, null);
		});
	}

	@Test
	void getBalance_InitialBalanceLessThanFee() {
		account = new DebitAccount("debit123", BigDecimal.ZERO, BigDecimal.TEN);
		
		BigDecimal balance = account.calculateCurrentBalance();
		
		assertEquals(Account.getZeroBalance(), balance);
	}

	@Test
	void getBalance_InitialBalanceGreaterThanFee() {
		account = new DebitAccount("debit123", ONE_HUNDRED, BigDecimal.TEN);
		
		BigDecimal balance = account.calculateCurrentBalance();
		
		assertEquals(new BigDecimal("90.00"), balance);
	}



}

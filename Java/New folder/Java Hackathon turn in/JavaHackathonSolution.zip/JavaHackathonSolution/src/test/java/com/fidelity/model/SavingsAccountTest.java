package com.fidelity.model;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.math.BigDecimal;
import java.time.LocalDate;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * SavingsAccountTest defines unit tests for SavingsAccount.
 * 
 * @author ROI Instructor Team
 */
public class SavingsAccountTest {
	private SavingsAccount account;
	
	@BeforeEach
	void setUp() throws Exception {
	}

	@Test
	void createSavingAccount_Success( ) {
		String accountNumber = "saving123";
		account = new SavingsAccount(accountNumber, BigDecimal.TEN, LocalDate.now());
		
		String result = account.getAccountNumber();
		
		assertEquals(accountNumber, result);
	}

	@Test
	void createSavingAccount_EmptyAccountNumber_ThrowsException( ) {
		assertThrows(IllegalArgumentException.class, () -> {
			new SavingsAccount("", BigDecimal.TEN, LocalDate.now());
		});
	}

	@Test
	void createSavingAccount_NegativeInitialBalance_ThrowsException( ) {
		assertThrows(IllegalArgumentException.class, () -> {
			new SavingsAccount("saving123", new BigDecimal("-10.00"), LocalDate.now());
		});
	}

	@Test
	void createSavingAccount_NullStartDate_ThrowsException( ) {
		assertThrows(IllegalArgumentException.class, () -> {
			new SavingsAccount("saving123", BigDecimal.TEN, null);
		});
	}

	@Test
	void getBalance_ZeroBalance() {
		account = new SavingsAccount("saving123", BigDecimal.ZERO, LocalDate.now());
		
		BigDecimal balance = account.calculateCurrentBalance();
		
		assertEquals(Account.getZeroBalance(), balance);
	}

	@Test
	void getBalance_AgeLessThanOneYear_NoInterest() {
		account = new SavingsAccount("saving123", new BigDecimal("100.00"), LocalDate.now());
		
		BigDecimal balance = account.calculateCurrentBalance();
		
		assertEquals(new BigDecimal("100.00"), balance);
	}


	@Test
	void getBalance_AgeMotrThanOneYear_AccruesInterest() {
		account = new SavingsAccount("saving123", new BigDecimal("100.00"), 
				                    LocalDate.now().minusDays(367));
		
		BigDecimal balance = account.calculateCurrentBalance();
		
		assertEquals(new BigDecimal("103.00"), balance);
	}
}

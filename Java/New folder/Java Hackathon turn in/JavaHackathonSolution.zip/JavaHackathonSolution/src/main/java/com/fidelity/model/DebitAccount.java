package com.fidelity.model;

import java.math.BigDecimal;
import java.math.RoundingMode;

//import com.fidelity.utils.Generated;

/**
 * DebitAccount defines the properties of a debit account.
 * 
 * @author ROI Instructor Team
 */
public class DebitAccount extends Account {
	private final BigDecimal fee; // annual fee 

	public DebitAccount(String accountNumber, BigDecimal balance, BigDecimal fee) {
		super(accountNumber, balance);
		if (fee == null || fee.compareTo(getZeroBalance()) < 0) {
			throw new IllegalArgumentException("fee must be greater than or equal to 0");
		}
		this.fee = fee;
	}

	/**
	 * Calculate the debit account balance. The fee is subtracted from the initial balance.
	 */
	@Override
	public BigDecimal calculateCurrentBalance() {
		// the fee is the same regardless of the age of the account
		BigDecimal value = getBalance();
		// subtract the fee only if it won't result in a negative balance
		if (value.compareTo(fee) >= 0) {
			value = value.subtract(fee).setScale(2, RoundingMode.HALF_EVEN );
		}
		return value;
	}
	
	public BigDecimal getFee() {
		return fee;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + ((fee == null) ? 0 : fee.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		DebitAccount other = (DebitAccount) obj;
		if (fee == null) {
			if (other.fee != null)
				return false;
		} else if (!fee.equals(other.fee))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "DebitAccount [fee=" + fee + ", getGrossBalance()=" + getBalance() + ", getAccountNumber()="
				+ getAccountNumber() + "]";
	}	

}

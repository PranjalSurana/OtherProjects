package com.fidelity.model;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;

//import com.fidelity.utils.Generated;

/**
 * GicAccount defines the properties of a GIC account.
 * 
 * @author ROI Instructor Team
 */
public class GicAccount extends Account {
	private static final BigDecimal INTEREST_RATE = new BigDecimal("1.05");
	private final LocalDate startDate;
	private final int termInMonths;
	private final BigDecimal fee;

	/**
	 * This constructor is provided so unit tests can supply a start date for
	 * consistent test results. Production will probably call the other constructor,
	 * where the start date defaults to the current date.
	 */
	public GicAccount(String accountNumber, BigDecimal balance, LocalDate startDate, BigDecimal fee, int term) {
		super(accountNumber, balance);
		if (startDate == null) {
			throw new IllegalArgumentException("start date can't be null");
		}
		if (term < 1) {
			throw new IllegalArgumentException("Term less than a month not allowed");
		}
		if (fee == null || fee.compareTo(getZeroBalance()) < 0) {
			throw new IllegalArgumentException("fee must be greater than or equal to 0");
		}
		this.startDate = startDate;
		this.termInMonths = term;
		this.fee = fee;
	}

	/**
	 * Create a GIC with a start date of the current date.
	 */
	public GicAccount(String accountNumber, BigDecimal balance, BigDecimal fee, int term) {
		// pass the parameters to the other constructor in this class but supply
		// a default value for the start date.
		this(accountNumber, balance, LocalDate.now(), fee, term);
	}

	/**
	 * Calculate the GIC account balance. If the account was started more
	 * than one year ago, interest is added to the initial balance, and the
	 * fee is subtracted.
	 */
	@Override
	public BigDecimal calculateCurrentBalance() {
		// Calculate interests on an termInMonths basis only, for simplicity.
		// We also assume a fixed interest rate of 5%
		BigDecimal value = getBalance();
		if (LocalDate.now().isAfter(startDate.plusMonths(termInMonths))) {
			value = value.multiply(INTEREST_RATE);
		}
		// subtract the fee only if it won't result in a negative balance
		if (value.compareTo(fee) >= 0) {
			value = value.subtract(fee).setScale(2, RoundingMode.HALF_EVEN );
		}
		return value;
	}

	public LocalDate getStartDate() {
		return startDate;
	}

	public int getTermInMonths() {
		return termInMonths;
	}
	
	public BigDecimal getFee() {
		return fee;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + ((fee == null) ? 0 : fee.hashCode());
		result = prime * result + ((startDate == null) ? 0 : startDate.hashCode());
		result = prime * result + termInMonths;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		GicAccount other = (GicAccount) obj;
		if (fee == null) {
			if (other.fee != null)
				return false;
		} else if (!fee.equals(other.fee))
			return false;
		if (startDate == null) {
			if (other.startDate != null)
				return false;
		} else if (!startDate.equals(other.startDate))
			return false;
		if (termInMonths != other.termInMonths)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "GicAccount [startDate=" + startDate + ", termInMonths=" + termInMonths + ", fee=" + fee + ", getGrossBalance()="
				+ getBalance() + ", getAccountNumber()=" + getAccountNumber() + "]";
	}

}

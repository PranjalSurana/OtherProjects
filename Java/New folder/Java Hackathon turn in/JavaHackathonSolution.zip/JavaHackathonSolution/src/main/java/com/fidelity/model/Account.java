package com.fidelity.model;

import java.math.BigDecimal;

//import com.fidelity.utils.Generated;

/**
 * Account defines properties common to all account types.
 * 
 * @author ROI Instructor Team
 */
public abstract class Account {
	private static final BigDecimal ZERO_BALANCE = BigDecimal.ZERO.setScale(2);
	
	private final String accountNumber;
	// Subclasses need to be able to access the balance field in order to 
	// calculate their "real" balance, but they shouldn't be able to modify 
	// the balance field. So we'll declare the field private and add a protected 
	// getter method.
	private final BigDecimal balance;
	
	public Account(String accountNumber, BigDecimal balance) {
		if (accountNumber == null || accountNumber.length() == 0) {
			throw new IllegalArgumentException("account number can't be null or empty");
		}
		if (balance == null || balance.compareTo(getZeroBalance()) < 0) {
			throw new IllegalArgumentException("initial balance must be greater than or equal to 0");
		}
		this.accountNumber = accountNumber;
		this.balance = balance.setScale(2);
	}

	// The protected modifier allows subclasses to access the balance field, 
	// but prevents client code from getting the raw balance. Client code
	// will call the public calculateCurrentBalance() method.
	protected BigDecimal getBalance() {
		return balance;
	}

	public abstract BigDecimal calculateCurrentBalance();
	
	public String getAccountNumber() {
		return accountNumber;
	}

	public static BigDecimal getZeroBalance() {
		return ZERO_BALANCE;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((accountNumber == null) ? 0 : accountNumber.hashCode());
		result = prime * result + ((balance == null) ? 0 : balance.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Account other = (Account) obj;
		if (accountNumber == null) {
			if (other.accountNumber != null)
				return false;
		} else if (!accountNumber.equals(other.accountNumber))
			return false;
		if (balance == null) {
			if (other.balance != null)
				return false;
		} else if (!balance.equals(other.balance))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Account [accountNr=" + accountNumber + ", balance=" + balance + "]";
	}
	
	
	
}

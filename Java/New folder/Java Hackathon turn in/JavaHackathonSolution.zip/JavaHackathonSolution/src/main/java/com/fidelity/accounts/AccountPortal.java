package com.fidelity.accounts;

import java.math.BigDecimal;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import com.fidelity.model.Account;
import com.fidelity.utils.ClientIdValidator;
//import com.fidelity.utils.Generated;

/**
 * AccountPortal manages a set of accounts associated with a specific user.
 *
 * @author ROI Instructor Team
 */
public class AccountPortal {
	public static final BigDecimal ZERO_BALANCE = BigDecimal.ZERO.setScale(2);

	// Note that fields that shouldn't be modified are declared "final"
	private final String clientId;
	private final int capacity;
	private Set<Account> portfolio;

	/**
	 * Initialize the AccountPortal.
	 * 
	 * @param clientId the user ID
	 * @param capacity maximum number of accounts that can be added to the portal
	 * @throws IllegalArgumentException if the user ID or capacity is invalid
	 */
	public AccountPortal(String clientId, int capacity) {
		ClientIdValidator clientIdValidator = new ClientIdValidator();
		if (!clientIdValidator.isValid(clientId)) {
			throw new IllegalArgumentException("invalid user ID " + clientId + 
					": " + ClientIdValidator.ERROR_MSG);
		}
		if (capacity < 1) {
			throw new IllegalArgumentException("capacity cannot be less than 1");
		}

		this.clientId = clientId;
		this.capacity = capacity;
		portfolio = new HashSet<>(capacity);
	}

	/**
	 * Add an account to the portal.
	 * 
	 * @param account the Account to be added.
	 * @throws IllegalArgumentException if the account parameter is null
	 * @throws IllegalStateException if the portal is already at maximum capacity
	 * @throws AccountPortalException if an account with the same account number is
	 * already present
	 */
	public void addAccount(Account account) {
		if (account == null) {
			throw new IllegalArgumentException("cannot add a null account");
		}
		if (getRemainingSpaceForAccounts() == 0) {
			throw new IllegalStateException("account portal " + clientId + " is full");
		}
		String acctNum = account.getAccountNumber();
		if (getAccount(acctNum) != null) {
			throw new AccountPortalException("account " + acctNum + " is already in this portal");
		}
		portfolio.add(account);
	}

	/**
	 * Remove an account from the portal.
	 * 
	 * @param accountNumber the account to be removed
	 * @throws IllegalArgumentException if account parameter is null or
	 *         is not present in the portal
	 */
	public void removeAccount(String accountNumber) {
		if (accountNumber == null) {
			throw new IllegalArgumentException("account number can't be null");
		}
		Iterator<Account> iter = portfolio.iterator();
		while (iter.hasNext()) {
			Account account = iter.next();
			if (accountNumber.equals(account.getAccountNumber())) {
				iter.remove();
				return;
			}
		}
		// we never found the account number, so throw an exception
		throw new IllegalArgumentException("account portal does not contain account " + accountNumber);
	}

	/**
	 * Get an account from the portal.
	 * 
	 * @param accountNumber the account number of the desired account
	 * @return the specified account, or null if the account isn't present in the portal
	 * @throws IllegalArgumentException if the account number is null or empty
	 */
	public Account getAccount(String accountNumber) {
		if (accountNumber == null || accountNumber.length() == 0) {
			throw new IllegalArgumentException("account number cannot be empty");
		}
		for (Account account: portfolio) {
			if (accountNumber.equals(account.getAccountNumber())) {
				return account;
			}
		}
		return null;
	}
	
	/**
	 * Calculate the total balance for all accounts.
	 * 
	 * @return the net total of all accounts
	 */
	public BigDecimal getAccountsTotalBalance() {
		BigDecimal total = ZERO_BALANCE;
		for (Account account : portfolio) {
			BigDecimal accountBalance = account.calculateCurrentBalance();
			total = total.add(accountBalance);
		}
		return total;
	}

	/**
	 * Get the maximum number of accounts this portal can manage.
	 */
	public int getMaximumNumberOfAccounts() {
		return capacity;
	}

	/**
	 * Get the remaining number of open spaces for new accounts.
	 */
	public int getRemainingSpaceForAccounts() {
		return capacity - portfolio.size();
	}
	
	public Set<Account> getPortfolio() {
		// return a copy of the portfolio, so client code can't modify the portfolio directly
		return Collections.unmodifiableSet(portfolio);
	}

	public String getClientId() {
		return clientId;
	}
	
   /**
     * For use in unit tests only; not for production code.
     *
     * Defines a method that unit tests can use to modify the internal state
     * of the portal. This allows unit tests to set up an AccountPortal with
     * a known initial state without relying on methods in the class's public API. 
     * 
     * This should never be called by client code, so we give it default package access, 
     * so it can't be called from code outside the current package.
     */
    /* package access */ void setPortfolio(Set<Account> accounts) {
		portfolio = accounts;
    }

}

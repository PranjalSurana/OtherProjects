package com.fidelity.accounts;

//import com.fidelity.utils.Generated;

/**
 * AccountPortalException is thrown by methods of Account
 * and its subclasses.
 * 
 * @author ROI Instructor Team
 */
public class AccountPortalException extends RuntimeException {
	private static final long serialVersionUID = 1L;

	public AccountPortalException() {
	}

	public AccountPortalException(String message) {
		super(message);
	}

	public AccountPortalException(Throwable cause) {
		super(cause);
	}

	public AccountPortalException(String message, Throwable cause) {
		super(message, cause);
	}

	public AccountPortalException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}
}

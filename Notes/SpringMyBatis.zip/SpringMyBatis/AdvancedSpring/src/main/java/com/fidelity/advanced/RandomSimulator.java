package com.fidelity.advanced;

public class RandomSimulator {
	double seed = 999.0;

	public void setSeed(double seed) {
		this.seed = seed;
	}

	public double getSeed() {
		return seed;
	}

}

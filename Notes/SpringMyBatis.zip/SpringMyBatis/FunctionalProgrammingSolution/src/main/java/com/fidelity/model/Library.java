package com.fidelity.model;

import java.util.Collections;
import java.util.List;


public class Library {
	private List<Book> books;
	
	public Library(List<Book> books) {
		this.books = books;
	}
	
	public void sortByPrice(){
		// Done: replace the PriceComparator instance with a lambda expression
		books.sort((b1, b2) -> Double.compare(b1.getPrice(), b2.getPrice()));
	}
	
	public void sortByTitle() {
		// Done: replace the anonymous inner class with a lambda expression
		books.sort((b1, b2) -> b1.getTitle().compareTo(b2.getTitle()));
	}

	public List<Book> getBooks() {
		return Collections.unmodifiableList(books);
	}

	// BONUS TODO:
	//    1. add two static methods to the Library class:
	//       compareBooksByTitle(Book b1, Book b2) 
	//       compareBooksByPrice(Book b1, Book b2) 
	//    2. In sortByTitle() and sortByPrice(), replace the lambda expressions 
	//       with method references

//	public static int compareBooksByPrice(Book b1, Book b2){
//		return Double.compare(b1.getPrice(), b2.getPrice());
//	}
//	
//	public static int compareBooksByTitle(Book b1, Book b2) {
//		return b1.getTitle().compareTo(b2.getTitle());
//	}
//
//	public void sortByPrice(){
//		books.sort(Library::compareBooksByPrice);
//	}
//	
//	public void sortByTitle() {
//		// Done: replace the anonymous inner class with a lambda expression
//		books.sort(Library::compareBooksByTitle);
//	}

}

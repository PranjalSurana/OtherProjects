package com.fidelity.streams;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.fidelity.model.Book;
import com.fidelity.model.DummyBookList;
import com.fidelity.model.Library;

public class StreamsTest {
	private List<Book> books;

	@BeforeEach
	public void setUp() throws Exception {
		Library lib = new Library(DummyBookList.createBooksList());
		books = lib.getBooks();
	}

	@Test
	// Done: write the test to find the count of all the books written by Robert Martin
	//       Use streams to do this
	public void testFindCountOfBooksByRobertMartin() {
		String author = "Robert Martin";
		
		long actual = books.stream()
						 .filter(b -> author.equals(b.getAuthor()))
						 .count();
		
		assertEquals(3, actual);
	}
	
	@Test
	// Done: write the test to find all the books less than $50
	//       Use streams to do this
	public void testFindBooksLessThanFiftyDollars() {

		List<Book> results = books.stream()
				.filter(b -> b.getPrice() < 50.0)
				.collect(Collectors.toList());

		assertEquals(6, results.size());
	}

	@Test
	// Done: Write the test to find all the books by Martin Fowler.
	//       Use streams to do this.
	public void testFindBooksByMartinFowler() {
		String author = "Martin Fowler";

		List<Book> results = books.stream()
								  .filter(b -> author.equals(b.getAuthor()))
								  .collect(Collectors.toList());

		assertEquals(3, results.size());
	}
	
	// BONUS STEPS: using the java.util.Optional class
	
	@Test
	// Done: Write the test to find the highest priced book.
	//       Use streams to do this. 
	public void testFindHighestPricedBook() {
		Book expectedBook = new Book("0321127420", "Martin Fowler", 54.03, "Patterns of Enterprise Application Architecture");

		Optional<Book> maxBook = books.stream()
									  .max(Comparator.comparing(Book::getPrice));

		assertEquals(expectedBook, maxBook.orElseThrow());
	}
	
	@Test
	// Done: Optional exercise: write the test to find any book written by Robert Martin
	//       Use streams to do this. You will need to use Optional<> again.
	public void testFindAnyBookByRobertMartin() {
		String author = "Robert Martin";

		Optional<Book> anyBook = books.stream()
									  .filter(b -> author.equals(b.getAuthor()))
									  .findAny();

		assertEquals(author, anyBook.orElseThrow().getAuthor());
	}
	
	// The following test cases demo additional stream techniques using the map() method

	@Test
	void testStreamMap() {
		List<String> names = List.of("One", "TWO", "ThrEE");

		List<String> lowernames = 
		    names.stream()
		         .map(s -> s.toLowerCase())
		         .toList();   // Java 17+

		assertEquals(List.of("one", "two", "three"), lowernames);
	}
	
	@Test
	void testBookStreamMap() {
		List<String> lowernames = 
		    DummyBookList.createBooksList().stream()
		         .map(b -> b.getTitle()) // get titles only OR use a method reference: msp(Book::getTitle)
		         .filter(s -> s.matches("^\\S+$"))  // one or more non-whitespace chars from beginning to end
		         .map(String::toLowerCase)  // OR use a lambda: s -> s.toLowerCase()
		         .toList();   // Java 17+

		lowernames.forEach(System.out::println);

		assertEquals(List.of("refactoring"), lowernames);
	}
}

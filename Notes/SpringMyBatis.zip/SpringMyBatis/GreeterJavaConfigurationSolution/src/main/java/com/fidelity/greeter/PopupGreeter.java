package com.fidelity.greeter;

import javax.swing.JOptionPane;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component ("greeter")
public class PopupGreeter implements Greeter {
	@Autowired
	@Qualifier("indiaVisitor")
	private Visitor visitor;
	
	public Visitor getVisitor() {
		return visitor;
	}

	public void greet() {
		JOptionPane.showMessageDialog(null, visitor.getGreeting() + ", " + visitor.getName());
	}

	@Override
	public String toString() {
		return "PopupGreeter [visitor=" + visitor + "]";
	}

}

package com.fidelity.greeter;

import org.springframework.stereotype.Component;

@Component("indiaVis")
public class IndiaVisitor implements Visitor {
	private String name;
	private String greeting;

	public IndiaVisitor() {
		this.name = "Neha Kakkar";
		this.greeting = "Mile Ho Tum";
		System.out.println("created " + toString());
	}
	
	public void setName(String name) {
		this.name = name;
	}

	public void setGreeting(String greeting) {
		this.greeting = greeting;
	}

	@Override
	public String getName() {
		return name;
	}

	@Override
	public String getGreeting() {
		return greeting;
	}

	@Override
	public String toString() {
		return "IndiaVisitor [name=" + name + ", greeting=" + greeting + "]";
	}
}

package com.fidelity.integration;

import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Many;
import org.apache.ibatis.annotations.Options;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.ResultMap;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import org.apache.ibatis.mapping.StatementType;

import com.fidelity.business.Department;
import com.fidelity.business.Employee;

public interface DepartmentMapper {
	@Select("""
			SELECT  deptno AS id, dname AS name, loc AS location 
			  FROM  dept 
		  ORDER BY  id
		""")
	List<Department> getAllDepartments();
	
	// Basic step: add @ResultMap to reference the result map from the XML mapping file
	@Select("""
			 SELECT  d.deptno AS id, d.dname, d.loc, e.empno, e.ename, e.job, e.mgr, 
					 e.hiredate, e.sal, e.comm, e.deptno 
			   FROM  dept d 
			   LEFT  OUTER JOIN emp e 
				 ON  d.deptno = e.deptno 
		   ORDER BY  id, e.empno
		""")
	@ResultMap("com.fidelity.integration.DepartmentMapper.DepartmentAndEmployees")
	List<Department> getAllDepartmentsAndEmployees();
	
//	// Bonus step: map results with @Result instead of @ResultMap: no XML required
//	@Select("""
//			SELECT  deptno, dname, loc 
//			  FROM  dept
//		  ORDER BY  deptno
//		""")
//	@Result(property="id", column="DEPTNO", id=true)
//	@Result(property="name", column="DNAME")
//	@Result(property="location", column="LOC")
//	@Result(property="employees", column="DEPTNO", many=@Many(select="getEmployees"))  
//	// the "many" property above references the new getEmployees() method defined below
//	List<Department> getAllDepartmentsAndEmployees();
//	
//	// Bonus step: a method that returns all Employees for a given Department.
//	//             It satisfies the @Many Department-to-Employee relationship.
//	@Select("""
//			SELECT  empno, ename, job, mgr, hiredate, sal, comm, deptno
//  	        FROM  emp
//			 WHERE  deptno = #{deptId}
//  	    ORDER BY  empno
//		""")
//	@Result(property="id", column="empno", id=true)
//	@Result(property="name", column="ename")
//	@Result(property="job", column="job")
//	@Result(property="manager", column="mgr")
//	@Result(property="hireDate", column="hiredate")
//	@Result(property="salary", column="sal")
//	@Result(property="commission", column="comm")
//	@Result(property="deptId", column="deptno")
//	List<Employee> getEmployees(int deptId);
	
	@Insert("""
		INSERT  INTO dept (deptno, dname, loc) 
		VALUES  (#{id}, #{name}, #{location})
	""")
	int insertDepartment(Department department);

	@Update("""
		UPDATE  dept 
		   SET  dname = #{name}, loc = #{location} 
		 WHERE  deptno = #{id}
	""")
	int updateDepartment(Department department);
	
	// Not required, but it allows us to demonstrate the constraint violation
	@Delete("""
			DELETE 
			  FROM  dept 
			 WHERE  deptno = #{id}
		""")
	int deleteDepartment(int deptId);

}

package com.fidelity.integration;

import org.springframework.stereotype.Repository;

@Repository("departmentsDao")
public class DepartmentDaoMyBatisImpl {
	

}

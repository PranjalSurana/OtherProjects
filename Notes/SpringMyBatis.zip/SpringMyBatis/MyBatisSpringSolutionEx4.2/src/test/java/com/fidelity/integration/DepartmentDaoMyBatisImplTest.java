package com.fidelity.integration;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.fidelity.business.Department;

@ExtendWith(SpringExtension.class)
@ContextConfiguration("classpath:beans.xml")
public class DepartmentDaoMyBatisImplTest {
	
	private Department dept10 = new Department(10, "ACCOUNTING", "NEW YORK");
	private Department dept20 = new Department(20, "RESEARCH", "DALLAS");
	private Department dept30 = new Department(30, "SALES", "CHICAGO");
	private Department dept40 = new Department(40, "OPERATIONS", "BOSTON");

//	10	ACCOUNTING	NEW YORK		10	7782	CLARK	09-JUN-81	MANAGER	7839	2450
//	10	ACCOUNTING	NEW YORK		10	7839	KING	17-NOV-81	PRESIDENT		5000
//	10	ACCOUNTING	NEW YORK		10	7934	MILLER	23-JAN-82	CLERK	7782	1300
//	
	// DONE: Deleted temporary test

	@Autowired
	private DepartmentDaoMyBatisImpl dao;

	@Test
	@DisplayName("Check all rows in the dept table")
	void testGetAllDepartments_Exhaustive() {
		
		List<Department> expected = Arrays.asList(dept10, dept20, dept30, dept40);

		List<Department> actual = dao.getAllDepartments();
		
		assertEquals(expected, actual);		
	}

	@Test
	@DisplayName("Check a few rows in the dept table")
	void testGetAllDepartments_CherryPick() {

		List<Department> actual = dao.getAllDepartments();
		
		assertEquals(4, actual.size());
		assertEquals(dept10, actual.get(0));		
		assertEquals(dept40, actual.get(3));		
	}
}














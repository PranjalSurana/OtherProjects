package com.fidelity.foo;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class FooFactory {
	public static Foo createFoo(String message) throws ClassNotFoundException, InstantiationException, 
	IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException, SecurityException {
		Class<?> clazz = Class.forName("com.fidelity.foo.Foo");

		Foo foo = (Foo) clazz.getConstructor(String.class).newInstance(message);

		return foo;
	}

	public static String invokeBar(String message) throws ClassNotFoundException, InstantiationException, 
	IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException, SecurityException {
		Class<?> clazz = Class.forName("com.fidelity.foo.Foo");

		Foo foo = (Foo) clazz.getConstructor(String.class).newInstance(message);
		
		Method method = clazz.getDeclaredMethod("bar");
		method.setAccessible(true);
		String msg = (String) method.invoke(foo);
		
		return msg;
	}
}

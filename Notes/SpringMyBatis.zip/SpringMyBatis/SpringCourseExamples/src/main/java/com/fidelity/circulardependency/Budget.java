package com.fidelity.circulardependency;

import org.springframework.stereotype.Component;

@Component
public class Budget {
    // no reference to a Film
}

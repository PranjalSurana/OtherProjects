package com.fidelity.integration;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Repository;

import com.fidelity.business.Book;

@Repository("bookDao")   // or @Component
public class MockBookDao implements BookDao {
	private static List<Book> books;
	
	static {
		books = List.of(
			new Book("Cryptonomicon", "Neal Stephenson", "", 1),
			new Book("Clean Code", "Robert Martin", "", 2),
			new Book("UML Distilled", "Martin Fowler", "", 3),
			new Book("Design Patterns", "Gamma, Helm, Johnson, Vlissides", "", 4)
		);
	}

	private boolean startsWithIgnoreCase(String str, String prefix) {
		return str.regionMatches(true, 0, prefix, 0, prefix.length());
	}

	@Override
	public List<Book> queryForAllBooks() {
		return queryBooksByTitle("");
	}

	@Override
	public List<Book> queryBooksByTitle(String title) {
		return books.stream()
				.filter(book -> startsWithIgnoreCase(book.getTitle(), title))
				.collect(Collectors.toList());
	}

}

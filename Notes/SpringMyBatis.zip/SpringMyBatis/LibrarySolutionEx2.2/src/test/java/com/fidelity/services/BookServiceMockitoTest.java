package com.fidelity.services;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Collections;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.mockito.Mockito.when;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.fidelity.business.Book;
import com.fidelity.integration.BookDao;

/**
 * BookServiceMockitoTest is a true unit test of BookService.
 * It proves that the loose coupling of classes produced with
 * dependency injection allows us to replace the production DAO 
 * with a Mockito mock during unit tests. The use of the mock lets 
 * us test paths through the code that are difficult or impossible 
 * to test using a tightly-coupled production configuration.
 */
class BookServiceMockitoTest {
	@InjectMocks
	private BookService bookService;
	@Mock
	private BookDao mockBookDao;

	private Book crypto = new Book("Cryptonomicon", "Neal Stephenson", "", 1); 
	private Book cleanCode = new Book("Clean Code", "Robert Martin", "", 2); 
	private Book uml = new Book("UML Distilled", "Martin Fowler", "", 3); 
	private Book designPatterns = new Book("Design Patterns", "Gamma, Helm, Johnson, Vlissides", "", 4);
	
	List<Book> allBooks = List.of(crypto, cleanCode, uml, designPatterns);

	@BeforeEach
	void setUp() throws Exception {
		MockitoAnnotations.openMocks(this);
	}

	// The following tests were copied from the integration test and refactored 
	// to use a mock DAO
	
	@Test
	@DisplayName("DAO returns many books")
	void testQueryAllBooks() {

		when(mockBookDao.queryForAllBooks())
			.thenReturn(allBooks);
		
		List<Book> actualBooks = bookService.queryAllBooks();
		
		assertEquals(allBooks, actualBooks);
	}

	@Test
	void testQueryBooksByTitle_FoundOneMatch() {
		when(mockBookDao.queryForAllBooks())
			.thenReturn(allBooks);

		List<Book> actualBooks = bookService.queryBooksByTitle("UML");
		
		assertEquals(1, actualBooks.size());
		assertEquals(uml, actualBooks.get(0));
	}

	@Test
	void testQueryBooksByTitle_FoundMultipleMatches() {
		when(mockBookDao.queryForAllBooks())
			.thenReturn(allBooks);

		List<Book> actualBooks = bookService.queryBooksByTitle("c");
		
		assertEquals(2, actualBooks.size());
		assertTrue(actualBooks.contains(crypto), "Cryptonomicon is not on the list");
		assertTrue(actualBooks.contains(cleanCode), "Clean Code is not on the list");
	}
	
	@Test
	void testQueryBookByTitle_NotFound() {
		when(mockBookDao.queryForAllBooks())
			.thenReturn(allBooks);

		List<Book> actualBooks = bookService.queryBooksByTitle("COBOL");
		
		assertTrue(actualBooks.isEmpty(), "list should be empty");
	}

	// The following tests verify the BookService's behavior with conditions
	// that can't be tested easily (or at all) in an integration test

	@Test
	void queryAllBooks_DaoReturnsEmptyList() {

		when(mockBookDao.queryForAllBooks())
			.thenReturn(List.of());
		
		List<Book> actualBooks = bookService.queryAllBooks();
		
		assertEquals(Collections.EMPTY_LIST, actualBooks);
	}

	@Test
	void queryAllBooks_DaoReturnsNull() {

		when(mockBookDao.queryForAllBooks())
			.thenReturn(null);
		
		List<Book> actualBooks = bookService.queryAllBooks();
		
		assertNull(actualBooks);
	}

}

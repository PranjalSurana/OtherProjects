-- Drop the tables 
drop table widgets;
drop table gadgets;
package com.fidelity.restcontroller;

import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;

import com.fidelity.business.service.WarehouseBusinessService;

/**
 * WarehouseController is a RESTful web service.
 * It provides web methods to manage Widgets and Gadgets 
 * in the Warehouse database.
 * 
 * There is no business logic in this class; all business rules in
 * terms of validating data, defining transaction boundaries, etc.,
 * are implemented in the business service.
 * 
 * @author ROI Instructor
 *
 */

// TODO: add the required Spring annotations:
//       1. identify this class as a RESTful controller
//       2. configure the URL that will trigger method calls
// HINT: see slide 1-22

public class WarehouseController {
	
	// TODO: note the autowired business service field. The RESTful controller
	//       will delegate all input validation and database operations to the 
	//       business service.
	//       (no code changes required)
	@Autowired
	private WarehouseBusinessService service;

	@GetMapping(value="/ping",
				produces=MediaType.ALL_VALUE)
	public String ping() {
		return "Warehouse web service is alive at " + LocalDateTime.now();
	}
	
	// **** Widget methods ****
	
	// TODO: define CRUD operations for widgets
	
	// Get all widgets
	
	// Get one widget by ID
	
	// Insert a widget
	
	// Update a widget

	// Delete a widget

	// **** Gadget methods ****

	// BONUS TODO: define CRUD operations for gadgets
	
	
}


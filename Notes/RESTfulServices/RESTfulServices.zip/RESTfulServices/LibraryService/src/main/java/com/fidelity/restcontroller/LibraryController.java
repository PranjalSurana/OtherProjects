package com.fidelity.restcontroller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fidelity.business.Book;
import com.fidelity.business.BookList;
import com.fidelity.integration.LibraryDao;

@RestController
@RequestMapping("/library")
public class LibraryController {
	@Autowired
	private LibraryDao dao;
	
	public LibraryController() {
	}

	// GET http://localhost:8080/library/books
	public BookList getBooks() {
	
		BookList books = null;
				
		return books;
	}

	// GET http://localhost:8080/library/978-0060512804
	public Book getBookById(String id) {

		Book book = null;
		
		return book;
	}
}

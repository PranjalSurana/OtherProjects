# Blogging Platform Hackathon

This is a second hackathon that you can complete after you've 
submitted your first hackathon. It's a bit more challenging than
the first hackathon because the database relationships are more
complex, and some of the tasks are more involved.

Read the instructions carefully. Then write good tests and write good code.

*Task:* Implement a DAO for a blogging platform where users can 
create, update, retrieve, and delete blog posts. Each blog post has
properties such as title, content, author name, tag, and publication date.

See the interface in BlogDao.java for the methods you are required to implement.

See the model class in BlogPost.java for the properties you must populate.

## Database Relationships

blog_author has a one-to-many relationship with blog_post
    - Note that some authors have no blog posts.

blog_post has a many-to-one relationship with blog_tag
    - IRL a blog post may have several tags, and a tag may be shared by many
	  blog posts. But an implementation of that many-to-many relationship 
	  requires the addition of a link/join table, which makes the code 
	  considerably more complex. For simplicity, we'll allow a blog post 
	  to have at most one tag.

## Bonus Tasks

1. After you implement the methods in BlogDao.java, make the relationship between
   BlogPost and BlogAthor bi-directional. You can do this by adding a property
   blogPosts to BlogAuthor. Because the BlogAuthor-BlogPost relationship is 
   one-to-many, the BlogAuthor.blogPosts property should be a collection of BlogPost. 

   Now BlogAuthor HAS-A BlogPost, and BlogPost HAS-A BlogAuthor: it's a circular
   reference. To resolve the circular reference, create a BlogAuthor with no
   BlogPost list. Then create the collection of BlogPosts, setting the author
   property of each. Finally, call the BlogAuthor.setBlogPosts() method to set
   the author's blogPosts property.

2. 

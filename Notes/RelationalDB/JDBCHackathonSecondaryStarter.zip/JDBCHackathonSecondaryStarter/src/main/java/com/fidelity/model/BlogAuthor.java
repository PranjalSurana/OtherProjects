package com.fidelity.model;

import java.util.List;
import java.util.Objects;

/**
 * BlogAuthor defines the properties of a blog author.
 * 
 * @author ROI Instructor Team
 */
public class BlogAuthor {
	// You may not change the datatype of any of the properties of BlogAuthor
	private long id;
	private String name;
	private String emailAddress;
	private List<BlogPost> blogPosts;

	public BlogAuthor() {}

	public BlogAuthor(long id, String name, String emailAddress, List<BlogPost> blogPosts) {
		super();
		this.id = id;
		this.name = name;
		this.emailAddress = emailAddress;
		this.blogPosts = blogPosts;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public List<BlogPost> getBlogPosts() {
		return blogPosts;
	}

	public void setBlogPosts(List<BlogPost> blogPosts) {
		this.blogPosts = blogPosts;
	}

	@Override
	public int hashCode() {
		return Objects.hash(blogPosts, emailAddress, id, name);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!(obj instanceof BlogAuthor)) {
			return false;
		}
		BlogAuthor other = (BlogAuthor) obj;
		return Objects.equals(blogPosts, other.blogPosts) && Objects.equals(emailAddress, other.emailAddress)
				&& id == other.id && Objects.equals(name, other.name);
	}

	@Override
	public String toString() {
		return "BlogAuthor [id=" + id + ", name=" + name + ", emailAddress=" + emailAddress + "]";
	}
	
}

package com.fidelity.integration;

import java.util.List;

import com.fidelity.model.BlogPost;

/**
 * BlogDao defines the methods for all Blog DAO implementations.
 * 
 * @author ROI Instructor Team
 */
public interface BlogDao {
	/*
	 * You may not make any changes to these methods.
	 *
	 * Implement as many of these methods as time permits. You probably won't have
	 * time to finish them all, but you'll learn a lot even if you complete only one.
	 *	
	 * Suggested implementation strategy:
	 * 1. Implement the model classes first: that way you'll know what data to query
	 * 2. Write a test case for the first method (trust me! it WILL make your life easier!)
	 * 3. Implement the DAO method to make the first test case pass
	 * 4. Repeat steps 2 and 3 for each method in this interface, one at a time.
	 */
	
	/** Get all blog posts for the given author */
	List<BlogPost> getBlogPostsByAuthor(String authorEmail);

	/** Get all blog posts with the given tag */
	List<BlogPost> getBlogPostsByTag(String tag);

	/**
	 * Add a new blog post. 
	 * Version 1: easy
	 *     Assume author and tag are already present.
	 * Version 2: harder
	 *     If the post's author is not already present, add the author,
	 *     otherwise use the existing author.
	 *     If the post's tag is not already present, add the tag,
	 *     otherwise use the existing tag.
	 */
	void addBlogPost(BlogPost blogPost);  

	/** 
	 * Delete an existing blog post. 
	 */
	void deleteBlogPost(long blogPostId);

	/**
	 * Update an existing blog post. 
	 */
	void updateBlogPost(BlogPost blogPost);
}

package com.fidelity.model;

import java.time.LocalDateTime;
import java.util.Objects;

/**
 * BlogPost defines the properties of a blog post.
 * BlogPost has a many-to-one relationship with BlogAuthor, but note that not
 * every author has blog posts.
 * BlogPost has a one-to-one relationship with BlogTag, but note that not
 * every post has a tag.
 * 
 * @author ROI Instructor Team
 */
public class BlogPost {
	// You may not change the datatype of any of the properties of BlogPost
	private long id;
	private LocalDateTime publicationDateTime;
	private String title;
	private String content;
	private BlogAuthor author;
	private BlogTag tag;

	public BlogPost() {}

	public BlogPost(long id, LocalDateTime publicationDateTime, String title, String content, 
					BlogAuthor author, BlogTag tag) {
		this.id = id;
		this.publicationDateTime = publicationDateTime;
		this.title = title;
		this.content = content;
		this.author = author;
		this.tag = tag;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public LocalDateTime getPublicationDateTime() {
		return publicationDateTime;
	}

	public void setPublicationDateTime(LocalDateTime publicationDateTime) {
		this.publicationDateTime = publicationDateTime;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public BlogAuthor getAuthor() {
		return author;
	}

	public void setAuthor(BlogAuthor author) {
		this.author = author;
	}

	public BlogTag getTag() {
		return tag;
	}

	public void setTag(BlogTag tag) {
		this.tag = tag;
	}

	/**
	 * IMPORTANT: BlogPost and BlogAuthor reference each other. To avoid an infinite loop,
	 * modify the generated method to include only the author's id, not the entire BlogAuthor object.
	 */
	@Override
	public int hashCode() {
		return Objects.hash(author.getId(),  // author, 
						    content, id, publicationDateTime, tag, title);
	}

	/**
	 * IMPORTANT: BlogPost and BlogAuthor reference each other. To avoid an infinite loop,
	 * modify the generated method to compare only the author's id, not the entire BlogAuthor object.
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!(obj instanceof BlogPost)) {
			return false;
		}
		BlogPost other = (BlogPost) obj;
		return Objects.equals(author.getId(), other.author.getId())  // Objects.equals(author, other.author) 
				&& Objects.equals(content, other.content) && id == other.id
				&& Objects.equals(publicationDateTime, other.publicationDateTime) && Objects.equals(tag, other.tag)
				&& Objects.equals(title, other.title);
	}

	@Override
	public String toString() {
		return "BlogPost [id=" + id + ", publicationDateTime=" + publicationDateTime + ", title=" + title + ", content="
				+ content + ", author=" + author + ", tag=" + tag + "]";
	}
}

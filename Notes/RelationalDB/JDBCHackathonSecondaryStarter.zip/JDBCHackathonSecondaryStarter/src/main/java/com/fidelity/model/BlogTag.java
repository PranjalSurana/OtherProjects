package com.fidelity.model;

import java.util.Objects;

/**
 * BlogTag defines the properties of tag for a BlogPost.
 * 
 * @author ROI Instructor Team
 */
public class BlogTag {
	// You may not change the datatype of any of the properties of BlogTag

	private long id; 
	private String tag;

	public BlogTag() {}

	public BlogTag(long id, String tag) {
		super();
		this.id = id;
		this.tag = tag;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getTag() {
		return tag;
	}

	public void setTag(String tag) {
		this.tag = tag;
	}

	@Override
	public int hashCode() {
		return Objects.hash(id, tag);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!(obj instanceof BlogTag)) {
			return false;
		}
		BlogTag other = (BlogTag) obj;
		return id == other.id && Objects.equals(tag, other.tag);
	}

	@Override
	public String toString() {
		return "BlogTag [id=" + id + ", tag=" + tag + "]";
	}

}

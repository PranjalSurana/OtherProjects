DROP TABLE blog_post;
DROP TABLE blog_tag;
DROP TABLE blog_author;

CREATE TABLE blog_author (
    id INTEGER,
    name VARCHAR2(100) NOT NULL,
    email_address VARCHAR2(100) NOT NULL UNIQUE,
    CONSTRAINT pk_author_id PRIMARY KEY(id)
    
);

CREATE TABLE blog_tag (
    id INTEGER,
    tag VARCHAR2(100) NOT NULL,
    CONSTRAINT pk_blog_tag_id PRIMARY KEY(id)
);

CREATE TABLE blog_post (
    id INTEGER,
    blog_author_id INTEGER NOT NULL,  -- blog_post has a many-to-one relationship with blog_author
	blog_tag_id INTEGER NULL,  -- blog_post has a many-to-one relationship with blog_tag
    publication_date_time DATE NOT NULL,
    title VARCHAR2(4000) NOT NULL,
    content VARCHAR2(4000) NOT NULL,
	-- Oracle's VARCHAR2 has a hard limit of 4000 characters.
	-- For longer strings, define the CONTENT column as a CLOB
	-- (Character Large Object) and handle the data using the
	-- java.sql.Clob type.
    CONSTRAINT pk_blog_post_id PRIMARY KEY(id),
    CONSTRAINT fk_blog_author_id FOREIGN KEY(blog_author_id) 
            REFERENCES blog_author(id),
    CONSTRAINT fk_blog_tag_id FOREIGN KEY(blog_tag_id) 
            REFERENCES blog_tag(id)
);

INSERT INTO blog_author (id, name, email_address) VALUES (1, 'Dale Cooper', 'dale.cooper@email.com');
INSERT INTO blog_author (id, name, email_address) VALUES (2, 'Aisha Khan', 'aisha.khan@email.com');
INSERT INTO blog_author (id, name, email_address) VALUES (3, 'Carlos Garcia', 'carlos.garcia@email.com');
INSERT INTO blog_author (id, name, email_address) VALUES (4, 'Sophia Zhang', 'sophia.zhang@email.com');
INSERT INTO blog_author (id, name, email_address) VALUES (5, 'Emmanuel Adebayo', 'emmanuel.adebayo@email.com');
INSERT INTO blog_author (id, name, email_address) VALUES (6, 'Ekaterina Ivanova', 'ekaterina.ivanova@email.com');
INSERT INTO blog_author (id, name, email_address) VALUES (7, 'Lucas Silva', 'lucas.silva@email.com');
INSERT INTO blog_author (id, name, email_address) VALUES (8, 'Mia Wong', 'mia.wong@email.com');

INSERT INTO blog_tag (id, tag) VALUES (1, 'Travel');
INSERT INTO blog_tag (id, tag) VALUES (2, 'Technology');
INSERT INTO blog_tag (id, tag) VALUES (3, 'Food');
INSERT INTO blog_tag (id, tag) VALUES (4, 'Lifestyle');
INSERT INTO blog_tag (id, tag) VALUES (5, 'Fitness');

-- Dale Cooper with Travel and Food tags
INSERT INTO blog_post (id, blog_author_id, blog_tag_id, publication_date_time, title, content) 
	VALUES (1, (SELECT id FROM blog_author WHERE email_address = 'dale.cooper@email.com'), 
			(SELECT id FROM blog_tag WHERE tag = 'Travel'), 
			to_date('2023-05-28 22:03:17', 'yyyy-mm-dd hh24-mi-ss'), 'My Journey to Thailand', 
			'Thailand is amazing! The beaches, the food... everything.');
INSERT INTO blog_post (id, blog_author_id, blog_tag_id, publication_date_time, title, content) 
	VALUES (2, (SELECT id FROM blog_author WHERE email_address = 'dale.cooper@email.com'), 
			(SELECT id FROM blog_tag WHERE tag = 'Food'), 
			to_date('2023-09-04 10:17:52', 'yyyy-mm-dd hh24-mi-ss'), 'Thai Cuisine at its Best', 
			'I tasted some of the best dishes in Bangkok.');

-- Aisha Khan with Technology tag

INSERT INTO blog_post (id, blog_author_id, blog_tag_id, publication_date_time, title, content) 
	VALUES (3, (SELECT id FROM blog_author WHERE email_address = 'aisha.khan@email.com'), 
			(SELECT id FROM blog_tag WHERE tag = 'Technology'), 
			to_date('2023-09-01 09:45:38', 'yyyy-mm-dd hh24-mi-ss'), 'Tech Trends in 2023', 
			'AI and Quantum Computing are taking the lead this year.');

-- Carlos Garcia with Lifestyle and Fitness tags
INSERT INTO blog_post (id, blog_author_id, blog_tag_id, publication_date_time, title, content) 
	VALUES (4, (SELECT id FROM blog_author WHERE email_address = 'carlos.garcia@email.com'), 
			(SELECT id FROM blog_tag WHERE tag = 'Lifestyle'), 
			to_date('2023-07-20 11:31:04', 'yyyy-mm-dd hh24-mi-ss'), 'Living the Dream', 
			'Simple ways to enhance your daily routine.');
INSERT INTO blog_post (id, blog_author_id, blog_tag_id, publication_date_time, title, content) 
	VALUES (5, (SELECT id FROM blog_author WHERE email_address = 'carlos.garcia@email.com'), 
			(SELECT id FROM blog_tag WHERE tag = 'Fitness'), 
			to_date('2023-08-31 14:22:09', 'yyyy-mm-dd hh24-mi-ss'), 'Gym Essentials', 
			'Here are some workout tips and essentials for beginners.');

-- Sophia Zhang with Travel tag
INSERT INTO blog_post (id, blog_author_id, blog_tag_id, publication_date_time, title, content) 
	VALUES (6, (SELECT id FROM blog_author WHERE email_address = 'sophia.zhang@email.com'), 
			(SELECT id FROM blog_tag WHERE tag = 'Travel'), 
			to_date('2023-04-04 23:57:41', 'yyyy-mm-dd hh24-mi-ss'), 'Exploring the Alps', 
			'The beauty of the Alps is unmatched. Must visit!');
INSERT INTO blog_post (id, blog_author_id, blog_tag_id, publication_date_time, title, content) 
	VALUES (7, (SELECT id FROM blog_author WHERE email_address = 'sophia.zhang@email.com'), 
			(SELECT id FROM blog_tag WHERE tag = 'Travel'), 
			to_date('2023-07-18 15:36:32', 'yyyy-mm-dd hh24-mi-ss'), 'Scuba Diving in Malaysia', 
			'Some of the best scuba diving in the world is here at Barracuda Point, Sipadan Island, Malaysia');
INSERT INTO blog_post (id, blog_author_id, blog_tag_id, publication_date_time, title, content) 
	VALUES (8, (SELECT id FROM blog_author WHERE email_address = 'sophia.zhang@email.com'), 
			(SELECT id FROM blog_tag WHERE tag = 'Lifestyle'), 
			to_date('2023-09-03 15:56:02', 'yyyy-mm-dd hh24-mi-ss'), 'Hygge: Relaxing the Danish Way', 
			'Hygge (hoo-ga) is Denmark''s recipe for happiness: a mix of coziness, warmth, good company, and simple pleasures. Think soft blankets and warm cocoa!');

-- Emmanuel Adebayo with Lifestyle tag
INSERT INTO blog_post (id, blog_author_id, blog_tag_id, publication_date_time, title, content) 
	VALUES (9, (SELECT id FROM blog_author WHERE email_address = 'emmanuel.adebayo@email.com'), 
			(SELECT id FROM blog_tag WHERE tag = 'Lifestyle'), 
			to_date('2023-08-13 16:30:43', 'yyyy-mm-dd hh24-mi-ss'), 'Art of Minimalism', 
			'Living with less might actually give you more.');

COMMIT;


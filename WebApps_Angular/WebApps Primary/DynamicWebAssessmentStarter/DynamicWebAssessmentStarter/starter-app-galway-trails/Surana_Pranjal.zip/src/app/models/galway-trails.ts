export class GalwayTrails {
    constructor(
        public name: string,
        public length: number,
        public timeToComplete: number,
        public drivingTime: number,
        public difficulty: string,
        public comments: string,
    ) {}
}
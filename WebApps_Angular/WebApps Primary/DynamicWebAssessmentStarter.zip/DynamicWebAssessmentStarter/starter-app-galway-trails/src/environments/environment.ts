export const environment = {
    production: true,
    serverUrl: 'http://books-api.roifrm.com:8765'
};

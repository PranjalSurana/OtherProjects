export const environment = {
    production: false,
    serverUrl: 'http://localhost:8080'
};

class EventModel {
    id;
    title;
    description;
    location;
    likes;
    dislikes;
    eventDate;
    sortDate;
}

module.exports = EventModel;

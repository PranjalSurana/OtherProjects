/**
 * Place to store data specific to this instance
 * DO NOT store secrets here
 * DO NOT store state here - must be part of a stateless service
 */
class AppConfig {
    team = 'Mandolorian';
    version = '1.0.0';
}
module.exports = AppConfig;

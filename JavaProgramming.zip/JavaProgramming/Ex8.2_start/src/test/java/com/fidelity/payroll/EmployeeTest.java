package com.fidelity.payroll;

/*
 * There are now no tests here at all. All functionality of the superclass is tested
 * in the subclasses. This class will be removed shortly.
 */
class EmployeeTest {
	

}

package com.fidelity.payroll;

import java.util.Arrays;

public class EmployeeUtil {

	public static void sortByName(Employee[] emps) {
		Arrays.sort(emps, new EmployeeNameComparator());
	}

	public static void sortByMonthlyPay(Employee[] emps) {
		Arrays.sort(emps, new EmployeeMonthlyPayComparator());
	}


}

package com.fidelity.rating;

public class VideoGame {
	// TODO: note the constant String fields defined for ratings
	public static final String EVERYONE = "Everyone";
	public static final String EVERYONE_10_PLUS = "Everyone 10+";
	public static final String TEEN = "Teen";
	public static final String MATURE = "Mature";
	public static final String ADULTS_ONLY = "Adults Only";
	public static final String RATING_PENDING = "Rating Pending";

	// TODO: note the rating is defined as a String
	private final String rating;
	private final String title;

	// TODO: note the constructor's rating argument is a String
	public VideoGame(String title, String rating) {
		this.title = title;
		this.rating = rating;
	}

	public String getRating() {
		return rating;
	}
	
	public String getTitle() {
		return title;
	}

	public String toString() {
		return title + ", rated " + rating;
	}
}

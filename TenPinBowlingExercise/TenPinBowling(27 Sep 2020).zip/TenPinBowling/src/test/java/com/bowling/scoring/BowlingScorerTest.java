package com.bowling.scoring;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import com.bowling.model.BowlingGame;
import com.bowling.model.Frame;

class BowlingScorerTest {
	
	static BowlingScorer scorer;
	
	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		scorer = new SimpleBowlingScorer();
	}

	@BeforeEach
	void setUp() throws Exception {
	}

	@Test	// Basic sanity test
	void testScorer() {
		assertNotNull(scorer);
	}

	@Test   // Every throw is a gutter ball. Sad!
	void testZeroGame() {
		BowlingGame game = new BowlingGame();
		int expected = 0;
		int actual = scorer.calculateScore(game);
		
		assertEquals(expected, actual);
	}

	
	@Test    // Knock down 5 pins on every throw
	void test50Game() {
		BowlingGame game = create50Game();
		int expected = 50;
		int actual = scorer.calculateScore(game);
		
		assertEquals(expected, actual);
	}
	
	@Test    // A spare in every Frame
	void testScoreAllSparesGame() {
		BowlingGame game = createAllSparesGame();
		int expected = 150;
		int actual = scorer.calculateScore(game);
		
		assertEquals(expected, actual);
	}
	
	@Test   // Every throw is a strike! Perfect!
	void testScorePerfectGame() {
		BowlingGame perfectGame = createPerfectGame();
		int expected = 300;
		int actual = scorer.calculateScore(perfectGame);
		
		assertEquals(expected, actual);
	}
	
	/************************ Utility Methods *************************/
	BowlingGame createPerfectGame() {
		Frame[] frames = new Frame[10];
		Frame extraFrame = new Frame (10, 10);
		frames[9] = new Frame(10, 0, extraFrame);
		for(int i = 8; i >= 0; i--) {
			Frame frame = new Frame(10, 0, frames[i + 1]);
			frames[i] = frame;			
		}
		
		return new BowlingGame(frames);
	}
	
	BowlingGame create50Game() {
		Frame[] frames = new Frame[10];
		Frame extraFrame = new Frame (0, 0);
		frames[9] = new Frame(5, 0, extraFrame);
		for(int i = 8; i >= 0; i--) {
			Frame frame = new Frame(5, 0, frames[i + 1]);
			frames[i] = frame;			
		}
		
		return new BowlingGame(frames);
	}
	
	BowlingGame createAllSparesGame() {
		Frame[] frames = new Frame[10];
		Frame extraFrame = new Frame (5, 0);
		frames[9] = new Frame(5, 5, extraFrame);
		for(int i = 8; i >= 0; i--) {
			Frame frame = new Frame(5, 5, frames[i + 1]);
			frames[i] = frame;			
		}
		
		return new BowlingGame(frames);
	}
}

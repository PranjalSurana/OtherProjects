package com.bowling.scoring;


import com.bowling.model.BowlingGame;
import com.bowling.model.Frame;

public class SimpleBowlingScorer implements BowlingScorer {

	@Override
	public int calculateScore(BowlingGame game) {
		int score = 0;
		
		Frame[] frames = game.getFrames();
		
		for(int i = 0; i < frames.length; i++) {
			score += frames[i].getScore();
		}
		
		return score;
	}

}

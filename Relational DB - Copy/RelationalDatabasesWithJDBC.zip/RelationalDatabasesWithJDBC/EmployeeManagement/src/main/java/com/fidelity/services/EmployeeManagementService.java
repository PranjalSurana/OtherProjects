package com.fidelity.services;

import com.fidelity.integration.EmployeeDao;

public class EmployeeManagementService {
	private final EmployeeDao dao;
	
	public EmployeeManagementService(EmployeeDao dao) {
		this.dao = dao;
	}

	

}

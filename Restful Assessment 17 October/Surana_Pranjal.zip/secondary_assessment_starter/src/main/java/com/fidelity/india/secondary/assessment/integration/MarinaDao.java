package com.fidelity.india.secondary.assessment.integration;

public interface MarinaDao {

    String getMarinaName(String vesselName);

}
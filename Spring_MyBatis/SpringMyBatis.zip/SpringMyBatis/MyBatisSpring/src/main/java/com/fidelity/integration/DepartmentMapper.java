package com.fidelity.integration;

public interface DepartmentMapper {

}

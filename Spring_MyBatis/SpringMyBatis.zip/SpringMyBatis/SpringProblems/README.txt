Run the music.sql database script before doing this exercise.
Run the music.sql script in SQL Developer while connected to the Scott database.
This will create the Music table and populate it with some sample data.
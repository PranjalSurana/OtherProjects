Before running the JUnit test in this project, run the exhibits.sql script, which is in the sql folder.

Run this script in SQLDeveloper while connected to the Scott database.

This will create the exhibits table and populate it with some sample data.
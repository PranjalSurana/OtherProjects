package com.fidelity.services;

public interface StringProvider {

	String provide();

}
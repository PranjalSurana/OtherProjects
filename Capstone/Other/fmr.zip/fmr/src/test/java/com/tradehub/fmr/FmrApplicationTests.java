package com.tradehub.fmr;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FmrApplicationTests {

	@Test
	void contextLoads() {
	}

}

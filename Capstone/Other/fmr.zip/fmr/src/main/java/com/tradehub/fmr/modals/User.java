package com.tradehub.fmr.modals;

public class User {
}

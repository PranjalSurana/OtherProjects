package com.fidelity.investmonkey.exception;

public class TradeException extends RuntimeException
{

	public TradeException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}

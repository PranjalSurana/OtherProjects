package com.fidelity.investmonkey;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fidelity.investmonkey.models.PriceData;


/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args ) throws JsonMappingException, JsonProcessingException
    {
    	
    }
}

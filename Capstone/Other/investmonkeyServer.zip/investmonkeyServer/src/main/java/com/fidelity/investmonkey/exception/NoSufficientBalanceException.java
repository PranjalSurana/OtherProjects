package com.fidelity.investmonkey.exception;

public class NoSufficientBalanceException extends RuntimeException
{

	public NoSufficientBalanceException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}

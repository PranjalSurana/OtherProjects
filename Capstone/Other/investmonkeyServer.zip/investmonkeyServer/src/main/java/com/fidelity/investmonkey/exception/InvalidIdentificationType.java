package com.fidelity.investmonkey.exception;

public class InvalidIdentificationType extends RuntimeException {

	public InvalidIdentificationType(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
}

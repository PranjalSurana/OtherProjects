package com.fidelity.investmonkey.exception;

public class InvalidClientException extends RuntimeException {

	public InvalidClientException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
}

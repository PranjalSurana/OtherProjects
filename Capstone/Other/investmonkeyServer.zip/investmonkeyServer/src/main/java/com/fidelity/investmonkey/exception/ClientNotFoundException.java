package com.fidelity.investmonkey.exception;

public class ClientNotFoundException extends RuntimeException
{

	public ClientNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}

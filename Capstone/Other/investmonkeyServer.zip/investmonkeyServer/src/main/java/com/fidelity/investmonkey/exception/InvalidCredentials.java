package com.fidelity.investmonkey.exception;

public class InvalidCredentials {
	
}

package com.fidelity.courseexamples;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public class AppTest {
    /**
     * Rigourous Test :-)
     */
	@Test
    public void testApp() {
        assertTrue( true );
    }
}
